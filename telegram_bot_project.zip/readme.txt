🚀 Як запустити Telegram-бота на Railway:

1. Перейди на https://railway.app
2. Створи новий проект → Upload ZIP → Завантаж цей архів.
3. У Railway → Settings → Variables додай:
   BOT_TOKEN = твій токен від BotFather.
4. Натисни Deploy.
5. Після деплою бот запуститься автоматично.
