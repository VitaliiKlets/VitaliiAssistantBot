# VitaliiAssistantBot (Railway + Telegram)

Готовый минимальный бот на `python-telegram-bot v20`. Работает на Railway.

## Быстрый старт
1) Открой `bot.py` и либо:
   - замени строку `YOUR_TELEGRAM_BOT_API_KEY` на свой токен, **ИЛИ**
   - на Railway добавь переменную окружения `TELEGRAM_TOKEN` со значением токена.

2) Залей проект на GitHub (или загрузись напрямую в Railway).
3) На Railway:
   - New Project → Deploy from GitHub (выбери репозиторий).
   - Убедись, что файлы в корне: `bot.py`, `requirements.txt`, `Procfile`.
   - (Если не вставлял токен в код) Добавь Variables → `TELEGRAM_TOKEN=<твой токен>`.
   - Нажми **Deploy**.

Готово — бот должен запуститься и отвечать в Telegram.

## Состав
- `bot.py` — код бота (v20 API: ApplicationBuilder, filters)
- `requirements.txt` — зависимости
- `Procfile` — команда запуска для Railway (`worker: python bot.py`)
